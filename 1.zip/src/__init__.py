from pipeline import mainfn

def start():
    mainfn()